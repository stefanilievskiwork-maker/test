<?php
// Save as /dashboard/test.php
echo "<h1>PHP Test Page</h1>";
echo "<p>PHP is working! ✅</p>";
echo "<p>Current time: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>Server info: " . $_SERVER['SERVER_SOFTWARE'] . "</p>";

// Test if config.php exists
if (file_exists('config.php')) {
    echo "<p>✅ config.php file exists</p>";
    
    // Try to include it
    try {
        require_once 'config.php';
        echo "<p>✅ config.php loaded successfully</p>";
        
        // Test database connection
        try {
            $db = getDB();
            echo "<p>✅ Database connection successful</p>";
            
            // Check if users table exists
            $stmt = $db->prepare("SHOW TABLES LIKE 'users'");
            $stmt->execute();
            if ($stmt->fetch()) {
                echo "<p>✅ Users table exists</p>";
                
                // Check if admin user exists
                $stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE username = 'admin'");
                $stmt->execute();
                $result = $stmt->fetch();
                if ($result['count'] > 0) {
                    echo "<p>✅ Admin user exists</p>";
                } else {
                    echo "<p>❌ Admin user does not exist - run the user creation SQL</p>";
                }
            } else {
                echo "<p>❌ Users table does not exist</p>";
            }
            
        } catch (Exception $e) {
            echo "<p>❌ Database error: " . $e->getMessage() . "</p>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ Config error: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>❌ config.php file not found</p>";
}

echo "<hr>";
echo "<h3>File Structure Check:</h3>";
echo "<ul>";
$files = ['config.php', 'login.php', 'logout.php', 'content.php', 'index.php'];
foreach ($files as $file) {
    if (file_exists($file)) {
        echo "<li>✅ $file</li>";
    } else {
        echo "<li>❌ $file</li>";
    }
}
echo "</ul>";

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<p><a href='login.php'>Test login.php</a></p>";
echo "<p><a href='index.php'>Test index.php</a></p>";
?>